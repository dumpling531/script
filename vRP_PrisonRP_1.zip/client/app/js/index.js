$(document).ready(function(){
	window.addEventListener( 'message', function( event ) {

		if ( event.data.type === "ON_Visible" ) {
			$('.shop').css('display','block');
		} else if(event.data.type === "OFF_Visible") {
			$('.shop').css('display','none');
		}
	});

	$("#Closebtn").click(function(){
		$.post('https://vRP_PrisonRP/Closebtn', JSON.stringify({}));2
	});
    $("#buy-btn-boltcutter").click(function(){
		$.post('https://vRP_PrisonRP/cutterTrigger', JSON.stringify({}));2
	});
    $("#buy-btn-carsupport").click(function(){
		$.post('https://vRP_PrisonRP/carSupportTrigger', JSON.stringify({}));2
	});
    $("#buy-btn-bulletproof").click(function(){
		$.post('https://vRP_PrisonRP/bulletProofTrigger', JSON.stringify({}));2
	});

})
