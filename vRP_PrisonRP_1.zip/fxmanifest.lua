fx_version 'cerulean'
games { 'gta5' }

ui_page 'client/app/index.html'

dependency "vrp"

lua54 'yes'

client_scripts{ 
	"@vrp/lib/MySQL.lua",
	"@vrp/lib/utils.lua",
	"@vrp/client/Tunnel.lua",
	"@vrp/client/Proxy.lua",
	"client/client.lua"
}

server_scripts{
	'@vrp/lib/utils.lua',
	'@vrp/lib/Tools.lua',
	'@vrp/lib/Proxy.lua',
	"@vrp/client/Tunnel.lua",
	"@vrp/lib/MySQL.lua",
	"server/server.lua"
}

files {
    'client/**/*.html',
    'client/**/*.css',
    'client/**/*.js',
    'client/**/*.png',
    'client/**/*.jpg'
}