using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MenuAPI;
using Newtonsoft.Json;
using CitizenFX.Core;
using static CitizenFX.Core.UI.Screen;
using static CitizenFX.Core.Native.API;
using static vMenuClient.CommonFunctions;
using static vMenuShared.PermissionsManager;
using vMenuShared;

namespace vMenuClient
{
    public class WeatherOptions
    {
        // Variables
        private Menu menu;
        public MenuCheckboxItem dynamicWeatherEnabled;
        public MenuCheckboxItem blackout;
        public MenuCheckboxItem snowEnabled;
        public static readonly List<string> weatherTypes = new List<string>()
        {
            "�ſ� ����",
            "���� ����",
            "����",
            "�Ȱ�",
            "£�� �Ȱ�",
            "������",
            "�帲",
            "����",
            "��",
            "õ��",
            "��ǳ",
            "��",
            "���� ������",
            "ũ��������",
            "�ҷ���"
        };

        private void CreateMenu()
        {
            // Create the menu.
            menu = new Menu(Game.Player.Name, "���� ����");

            dynamicWeatherEnabled = new MenuCheckboxItem("���� ��ȯ ON/OFF", "Enable or disable dynamic weather changes.", EventManager.DynamicWeatherEnabled);
            blackout = new MenuCheckboxItem("��� ���� ON/OFF", "This disables or enables all lights across the map.", EventManager.IsBlackoutEnabled);
            snowEnabled = new MenuCheckboxItem("�ܿ� ����Ʈ ON/OFF", "This will force snow to appear on the ground and enable snow particle effects for peds and vehicles. Combine with X-MAS or Light Snow weather for best results.", ConfigManager.GetSettingsBool(ConfigManager.Setting.vmenu_enable_snow));
            MenuItem extrasunny = new MenuItem("�ſ� ����", "Set the weather to ~y~extra sunny~s~!") { ItemData = "EXTRASUNNY" };
            MenuItem clear = new MenuItem("���� ����", "Set the weather to ~y~clear~s~!") { ItemData = "CLEAR" };
            MenuItem neutral = new MenuItem("����", "Set the weather to ~y~neutral~s~!") { ItemData = "NEUTRAL" };
            MenuItem smog = new MenuItem("�Ȱ�", "Set the weather to ~y~smog~s~!") { ItemData = "SMOG" };
            MenuItem foggy = new MenuItem("£�� �Ȱ�", "Set the weather to ~y~foggy~s~!") { ItemData = "FOGGY" };
            MenuItem clouds = new MenuItem("������", "Set the weather to ~y~clouds~s~!") { ItemData = "CLOUDS" };
            MenuItem overcast = new MenuItem("�帲", "Set the weather to ~y~overcast~s~!") { ItemData = "OVERCAST" };
            MenuItem clearing = new MenuItem("����", "Set the weather to ~y~clearing~s~!") { ItemData = "CLEARING" };
            MenuItem rain = new MenuItem("��", "Set the weather to ~y~rain~s~!") { ItemData = "RAIN" };
            MenuItem thunder = new MenuItem("õ��", "Set the weather to ~y~thunder~s~!") { ItemData = "THUNDER" };
            MenuItem blizzard = new MenuItem("��ǳ", "Set the weather to ~y~blizzard~s~!") { ItemData = "BLIZZARD" };
            MenuItem snow = new MenuItem("��", "Set the weather to ~y~snow~s~!") { ItemData = "SNOW" };
            MenuItem snowlight = new MenuItem("���� ������", "Set the weather to ~y~light snow~s~!") { ItemData = "SNOWLIGHT" };
            MenuItem xmas = new MenuItem("ũ��������", "Set the weather to ~y~x-mas~s~!") { ItemData = "XMAS" };
            MenuItem halloween = new MenuItem("�ҷ���", "Set the weather to ~y~halloween~s~!") { ItemData = "HALLOWEEN" };
            MenuItem removeclouds = new MenuItem("���� ���� ����", "Remove all clouds from the sky!");
            MenuItem randomizeclouds = new MenuItem("��� ���� ����", "Add random clouds to the sky!");

            if (IsAllowed(Permission.WODynamic))
            {
                menu.AddMenuItem(dynamicWeatherEnabled);
            }
            if (IsAllowed(Permission.WOBlackout))
            {
                menu.AddMenuItem(blackout);
            }
            if (IsAllowed(Permission.WOSetWeather))
            {
                menu.AddMenuItem(snowEnabled);
                menu.AddMenuItem(extrasunny);
                menu.AddMenuItem(clear);
                menu.AddMenuItem(neutral);
                menu.AddMenuItem(smog);
                menu.AddMenuItem(foggy);
                menu.AddMenuItem(clouds);
                menu.AddMenuItem(overcast);
                menu.AddMenuItem(clearing);
                menu.AddMenuItem(rain);
                menu.AddMenuItem(thunder);
                menu.AddMenuItem(blizzard);
                menu.AddMenuItem(snow);
                menu.AddMenuItem(snowlight);
                menu.AddMenuItem(xmas);
                menu.AddMenuItem(halloween);
            }
            if (IsAllowed(Permission.WORandomizeClouds))
            {
                menu.AddMenuItem(randomizeclouds);
            }

            if (IsAllowed(Permission.WORemoveClouds))
            {
                menu.AddMenuItem(removeclouds);
            }

            menu.OnItemSelect += (sender, item, index2) =>
            {
                if (item == removeclouds)
                {
                    ModifyClouds(true);
                }
                else if (item == randomizeclouds)
                {
                    ModifyClouds(false);
                }
                else if (item.ItemData is string weatherType)
                {
                    Notify.Custom($"������ ~y~{item.Text}~s~�� ����˴ϴ�. {EventManager.WeatherChangeTime}�ʰ� �ɸ��ϴ�.");
                    UpdateServerWeather(weatherType, EventManager.IsBlackoutEnabled, EventManager.DynamicWeatherEnabled, EventManager.IsSnowEnabled);
                }
            };

            menu.OnCheckboxChange += (sender, item, index, _checked) =>
            {
                if (item == dynamicWeatherEnabled)
                {
                    Notify.Custom($"���� ������ {(_checked ? "~g~Ȱ��ȭ" : "~r~��Ȱ��ȭ")}~s~�ƽ��ϴ�.");
                    UpdateServerWeather(EventManager.GetServerWeather, EventManager.IsBlackoutEnabled, _checked, EventManager.IsSnowEnabled);
                }
                else if (item == blackout)
                {
                    Notify.Custom($"��� ������ {(_checked ? "~g~Ȱ��ȭ" : "~r~��Ȱ��ȭ")}~s~�ƽ��ϴ�.");
                    UpdateServerWeather(EventManager.GetServerWeather, _checked, EventManager.DynamicWeatherEnabled, EventManager.IsSnowEnabled);
                }
                else if (item == snowEnabled)
                {
                    Notify.Custom($"�� ����Ʈ�� {(_checked ? "~g~Ȱ��ȭ" : "~r~��Ȱ��ȭ")}~s~�ƽ��ϴ�.");
                    UpdateServerWeather(EventManager.GetServerWeather, EventManager.IsBlackoutEnabled, EventManager.DynamicWeatherEnabled, _checked);
                }
            };
        }



        /// <summary>
        /// Create the menu if it doesn't exist, and then returns it.
        /// </summary>
        /// <returns>The Menu</returns>
        public Menu GetMenu()
        {
            if (menu == null)
            {
                CreateMenu();
            }
            return menu;
        }
    }
}
