description 'chat management stuff modified by HDD for Realworld'

ui_page 'html/index.html'

dependency "vrp"

shared_script "@evp/main.lua"

client_scripts {
  "@vrp/client/Tunnel.lua",
	"@vrp/client/Proxy.lua",
  'cl_chat.lua',
}

server_scripts {
  "@vrp/lib/utils.lua",
  'sv_chat.lua'
}

files {
  'html/assets/logo.png',
  'html/css/index.css',
  'html/js/config.js',
  'html/js/index.js',
  'html/js/message.js',
  'html/index.html'
}
