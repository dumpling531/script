const config = {
  // 전환 효과 시간
  animateSpeed: 800,
  // 초기 상단 공지 메시지
  initHeaderNotice: '리얼월드에 접속하신 것을 환영합니다.',
  headerNoticeFocusStyle: 'animate-background',
  // 상단 가이드 표기 여부
  showHeaderTip: true,
  headerTipContent: '채널을 클릭해 비활성화/활성화 할 수 있어요!',

  defaultChatHeight: '300px',
  extendChatHeight: '70vh',

  channels: [
    {
      id: 'ic',
      name: '일반',
      selected: true,
      command: null,
      canSwitch: true,
      iconName: 'fas fa-comment',
      iconClass: '',
    },
    {
      id: 'twit',
      name: '트윗',
      selected: true,
      command: '트윗',
      canSwitch: true,
      iconName: 'fab fa-twitter-square',
      iconClass: 'twitter',
    },
    {
      id: 'ooc',
      name: '전체',
      selected: true,
      command: '전체',
      canSwitch: true,
      iconName: 'fas fa-globe-asia',
      iconClass: '',
    },
    {
      // Do not change this channel ID
      id: 'system',
      name: '시스템',
      selected: true,
      canSwitch: false,
    },
    {
      id: 'all',
      name: '전체 공지 채널',
      selected: true,
      canSwitch: false,
      ignoreSelect: true,
    }
  ],

  // Default Chat Configs
  defaultTemplateId: 'default', //This is the default template for 2 args1
  defaultAltTemplateId: 'defaultAlt', //This one for 1 arg
  templates: { //You can add static templates here
    'default': '<b>{0}</b>: {1}',
    'defaultAlt': '{0}',
    'example:important': '<h1>^2{0}</h1>'
  },
  fadeTimeout: 7000,
};


export default config;
