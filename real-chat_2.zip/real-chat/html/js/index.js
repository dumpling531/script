import CONFIG from './config.js';

const App = new Vue({
  el: '#app',
  name: 'app',
  data: {
    headerNotice: CONFIG.initHeaderNotice,
    headerNoticeClass: [],
    headerTipContent: CONFIG.headerTipContent,
    headerTipVisable: false,
    shouldHide: true,
    headerTipStyle: ['guide', 'animated'],
    inputVisable: false,
    channels: CONFIG.channels,
    currentChannel: {
      index: -1,
      name: '',
      icon: '',
      iconClass: ''
    },
    messages: [
    ],
    visableMessages: [
    ],

    // Chat Height Setting
    chatHeight: CONFIG.defaultChatHeight,

    // Mesasge Collector Configs
    messageCollector: null,
    messageCollectorTries: 0,

    // Default Chat Configs
    message: '',
    showWindow: false,
    templates: CONFIG.templates,
    oldMessages: [],
    oldMessagesIndex: -1,

  },
  destroyed() {
    clearInterval(this.focusTimer);
    window.removeEventListener('message', this.listener);
  },
  mounted() {
    // Initial Load Step
    if (CONFIG.showHeaderTip === true) {
      this.HEADER_NOTICE();
    }

    this.KEY_DOWN_TAB();
    this.FOCUS_INPUT();
    this.RELOAD_CHAT_MESSAGES();

    document.getElementById('app').classList.add('visable');

    post('http://real-chat/loaded', JSON.stringify({}));

    this.listener = window.addEventListener('message', (event) => {
      const item = event.data || event.detail; //'detail' is for debuging via browsers
      if (this[item.type]) {
        this[item.type](item);
      }
    });
  },
  watch: {
    messages() {
      if (this.showWindowTimer) {
        clearTimeout(this.showWindowTimer);
      }
      this.showWindow = true;
      this.resetShowWindowTimer();

      const messagesObj = this.$refs.messages;
      this.$nextTick(() => {
        messagesObj.scrollTop = messagesObj.scrollHeight;
      });
    },
  },
  methods: {
    ON_CHANGE_SHOW_UI: function ({ message }) {
      if (message.isShow) {
        document.getElementById('app').style.display = 'flex';
      } else {
        document.getElementById('app').style.display = 'none';
      }
    },
    ON_SCREEN_STATE_CHANGE({ shouldHide }) {
      this.shouldHide = shouldHide;
      if (shouldHide === false) {
        this.HEADER_NOTICE();
      }
    },
    ON_HEIGHT_CHANGE() {
      if (this.chatHeight === CONFIG.defaultChatHeight) {
        this.chatHeight = CONFIG.extendChatHeight;
        this.headerTipContent = "채팅 높이를 늘렸습니다."
      } else {
        this.chatHeight = CONFIG.defaultChatHeight;
        this.headerTipContent = "채팅 높이를 초기화하였습니다."
      }

      this.HEADER_NOTICE();
    },
    HEADER_NOTICE: function () {
      this.headerTipStyle.push('fadeIn');
      this.headerTipVisable = true;

      setTimeout(() => {
        const animateIndex = this.headerTipStyle.indexOf('fadeIn');
        this.headerTipStyle.splice(animateIndex, 1);
        this.headerTipStyle.push('fadeOut');

        setTimeout(() => {
          this.headerTipVisable = false;
          this.headerTipStyle = ['guide', 'animated'];
        }, CONFIG.animateSpeed);
      }, 3000);
    },
    FOCUS_INPUT: function () {
      if (this.$refs.input) {
        this.$refs.input.focus();
      }
    },
    HIDE_INPUT: function () {
      this.inputVisable = false;
      this.hideInput(true);
    },
    KEY_DOWN_TAB: function () {
      const switchableCh = this.channels.filter((e) => e.canSwitch === true);
      this.currentChannel.index = this.currentChannel.index + 1;
      if (this.currentChannel.index > switchableCh.length - 1) {
        this.currentChannel.index = 0;
      }

      this.REFRESH_TAB_WITH_INDEX(this.currentChannel.index);
    },
    KEY_DOWN_SPACE: function () {
      const input = String(this.$refs.input.value);
      if (input.startsWith('/')) {
        const switchableCh = this.channels.filter((e) => e.canSwitch === true);
        for (let index in switchableCh) {
          if (input.startsWith(`/${switchableCh[index].command}`)) {
            this.REFRESH_TAB_WITH_INDEX(index);
            this.$refs.input.value = '';
            event.preventDefault();
          }
        }
      }
    },
    REFRESH_TAB_WITH_INDEX: function (index) {
      const switchableCh = this.channels.filter((e) => e.canSwitch === true);
      this.currentChannel.index = index;
      this.currentChannel.name = switchableCh[index].name;
      this.currentChannel.icon = `<i class="${switchableCh[index].iconName}"></i>`;
      this.currentChannel.iconClass = switchableCh[index].iconClass;
    },
    RELOAD_CHAT_MESSAGES: function () {
      let enabledChannel = this.channels.filter((e) => e.selected === true);
      enabledChannel = enabledChannel.map((e) => e.id);

      this.messages = this.messages.slice(-100);

      this.visableMessages = [];
      Vue.nextTick(() => {
        this.visableMessages = this.messages.filter((e) => {
          let channel = e.channelId || "system";
          return enabledChannel.includes(channel);
        });

        const messagesObj = this.$refs.messages;
        this.$nextTick(() => {
          messagesObj.scrollTop = messagesObj.scrollHeight;
        });
      });
    },

    // Chat Methods
    ON_OPEN() {
      this.inputVisable = false;
      this.showWindow = true;
      if (this.showWindowTimer) {
        clearTimeout(this.showWindowTimer);
      }

      this.focusTimer = setInterval(() => {
        if (this.$refs.input) {
          this.$refs.input.focus();
        } else {
          clearInterval(this.focusTimer);
        }
      }, 100);

      this.inputVisable = true;
    },
    ON_MESSAGE: function (event) {
      const messagesObj = this.$refs.messages;
      const message = event.message;

      if (!message.channelId) {
        message.channelId = 'system';
      }

      this.messages = [...this.messages.slice(-100), message];

      let enabledChannel = this.channels.filter((e) => e.selected === true);
      enabledChannel = enabledChannel.map((e) => e.id);

      if (enabledChannel.includes(message.channelId)) {
        // Adding Message first to user, for UX
        this.visableMessages.push(message);

        const messageCollectorFunction = () => {
          if (this.visableMessages.length < 200 && this.messages.length < 200) {
              if (this.inputVisable === true)   {
              console.log('Could not clear messages due to input is visable, retrying after ', '5000 ms');
              const timeout = setTimeout(messageCollectorFunction, 5000)
              this.messageCollector = timeout;

              return;
            }  
          }

          if (this.visableMessages.length < 100 && this.messages.length < 100) {
            this.messageCollector = null;
            return;
          }

          this.messages = [...this.messages.slice(-100)];
          this.visableMessages = [];
          
          Vue.nextTick(() => {
            this.visableMessages = [...this.messages];  
            this.$nextTick(() => {
              messagesObj.scrollTop = messagesObj.scrollHeight;
            });  
          });

          this.messageCollector = null;  
        }

        if (this.messageCollector === null || this.messageCollector === undefined) {
          const timeout = setTimeout(messageCollectorFunction, 5000);
          this.messageCollector = timeout;  
        }
      }
    },
    CLEAR_MESSAGE: function () {
      this.messages = [];
      this.oldMessages = [];
      this.oldMessagesIndex = -1;
      this.RELOAD_CHAT_MESSAGES();
    },
    ON_CLEAR() {
      this.messages = [];
      this.oldMessages = [];
      this.oldMessagesIndex = -1;
      this.RELOAD_CHAT_MESSAGES();
    },
    ON_TEMPLATE_ADD({ template }) {
      this.warn('TEMPLATE ADD');
      if (this.templates[template.id]) {
        this.warn(`Tried to add duplicate template '${template.id}'`)
      } else {
        this.templates[template.id] = template.html;
      }
    },
    warn(msg) {
      this.messages.push({
        args: [msg],
        template: '^3<b>CHAT-WARN</b>: ^0{0}',
      });
    },
    clearShowWindowTimer() {
      clearTimeout(this.showWindowTimer);
    },
    resetShowWindowTimer() {
      this.clearShowWindowTimer();
      this.showWindowTimer = setTimeout(() => {
        if (!this.showInput) {
          this.showWindow = false;
        }
      }, CONFIG.fadeTimeout);
    },
    moveOldMessageIndex(up) {
      if (up && this.oldMessages.length > this.oldMessagesIndex + 1) {
        this.oldMessagesIndex += 1;
        this.message = this.oldMessages[this.oldMessagesIndex];
      } else if (!up && this.oldMessagesIndex - 1 >= 0) {
        this.oldMessagesIndex -= 1;
        this.message = this.oldMessages[this.oldMessagesIndex];
      } else if (!up && this.oldMessagesIndex - 1 === -1) {
        this.oldMessagesIndex = -1;
        this.message = '';
      }
    },
    resize() {
      const input = this.$refs.input;
      input.style.height = '5px';
      input.style.height = `${input.scrollHeight + 2}px`;
    },
    keyDown(e) {
      if (e.which === 38 || e.which === 40) {
        e.preventDefault();
        this.moveOldMessageIndex(e.which === 38);
      } else if (e.which == 33) {
        var buf = document.getElementsByClassName('chat-messages')[0];
        buf.scrollTop = buf.scrollTop - 100;
      } else if (e.which == 34) {
        var buf = document.getElementsByClassName('chat-messages')[0];
        buf.scrollTop = buf.scrollTop + 100;
      }
    },
    send(e) {
      if (this.message !== '' && this.message.replace(/g /, '') !== "") {
        let command = CONFIG.channels[this.currentChannel.index].command;

        post('http://real-chat/chatResult', JSON.stringify({
          message: this.message,
          channel: this.currentChannel.index,
          command,
        }));

        this.oldMessages.unshift(this.message);
        this.oldMessagesIndex = -1;
        this.hideInput();
      } else {
        this.hideInput(true);
      }
    },
    hideInput(canceled = false) {
      if (canceled) {
        post('http://real-chat/chatResult', JSON.stringify({ canceled }));
      }
      this.message = '';
      this.inputVisable = false;

      clearInterval(this.focusTimer);
      this.resetShowWindowTimer();
    },
    setHeaderText(e) {
      let text = e.text;
      if (!text) {
        text = CONFIG.initHeaderNotice;
      }

      this.headerNotice = text;
    },
    triggerHeaderFocus() {
      if (this.headerNoticeClass.includes(CONFIG.headerNoticeFocusStyle)) {
        // Already Focused
        this.headerNoticeClass = this.headerNoticeClass.filter((e) => e !== CONFIG.headerNoticeFocusStyle);
        return;
      }

      this.headerNoticeClass.push(CONFIG.headerNoticeFocusStyle);
    },
  }
});
