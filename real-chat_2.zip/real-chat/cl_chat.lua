vRP = Proxy.getInterface("vRP")

local chatInputActive = false
local chatInputActivating = false
local chatHidden = true
local chatLoaded = false
local isShowUI = true
local chatHeightChanging = false

RegisterNetEvent('chatMessage')
RegisterNetEvent('chat:addTemplate')
RegisterNetEvent('chat:addMessage')
RegisterNetEvent('chat:addSuggestion')
RegisterNetEvent('chat:addSuggestions')
RegisterNetEvent('chat:removeSuggestion')

-- internal events
RegisterNetEvent('__cfx_internal:serverPrint')
RegisterNetEvent('_chat:messageEntered')

RegisterNetEvent("chat:changeShowUI")
AddEventHandler(
  "chat:changeShowUI",
  function(isShow)
    isShowUI = isShow
    SendNUIMessage(
      {
        type = "ON_CHANGE_SHOW_UI",
        message = {
          isShow = isShow
        }
      }
    )
  end
)

--deprecated, use chat:addMessage
AddEventHandler(
  "chatMessage",
  function(author, color, text, class, channelId)
    local args = {text}

    if author ~= "" then
      table.insert(args, 1, author)
    end

    SendNUIMessage(
      {
        type = "ON_MESSAGE",
        message = {
          color = color,
          multiline = true,
          args = args,
          class = class or "",
          channelId = channelId
        }
      }
    )
  end
)

AddEventHandler('chat:addMessage', function(message)
  Citizen.Trace('Added Message')
  print(message)

  SendNUIMessage({
    type = 'ON_MESSAGE',
    message = message
  })
end)


-- Header Notice Events
local notice = false;
RegisterNetEvent('chat:headerNotice')
AddEventHandler('chat:headerNotice', function (text, stick)
  if (notice == true) then
    return;
  end

  if (stick == nil) then
    stick = false;
  end

  SendNUIMessage({
    type = 'setHeaderText',
    text = text
  });

  if (stick == true) then
    notice = true;
    SendNUIMessage({
      type = 'triggerHeaderFocus'
    });
  end
end)

RegisterNetEvent('chat:clearHeaderNotice')
AddEventHandler('chat:clearHeaderNotice', function (text, stick)
  if (notice == true) then
    SendNUIMessage({
      type = 'triggerHeaderFocus'
    });

    notice = false;
  end
  
  SendNUIMessage({
    type = 'setHeaderText',
  })
end)

-- Not using anymore (Suggestions)
-- AddEventHandler('chat:addSuggestion', function(name, help, params)
  
-- end)

-- AddEventHandler('chat:addSuggestions', function(suggestions)
--   for _, suggestion in ipairs(suggestions) do
--     SendNUIMessage({
--       type = 'ON_SUGGESTION_ADD',
--       suggestion = suggestion
--     })
--   end
-- end)

-- AddEventHandler('chat:removeSuggestion', function(name)
--   SendNUIMessage({
--     type = 'ON_SUGGESTION_REMOVE',
--     name = name
--   })
-- end)

-- Add Template
AddEventHandler('chat:addTemplate', function(id, html)
  SendNUIMessage({
    type = 'ON_TEMPLATE_ADD',
    template = {
      id = id,
      html = html
    }
  })
end)

-- Clear Message
AddEventHandler('chat:clear', function(name)
  SendNUIMessage({
    type = 'ON_CLEAR'
  })
end)

-- Chat Result Callback
RegisterNUICallback('chatResult', function(data, cb)
  chatInputActive = false
  SetNuiFocus(false)

  if not data.canceled then
    local id = PlayerId()
    local custom = {}
    custom.isJailed = vRP.isJailed({})
    custom.isComa = vRP.isInComa({})
    custom.isDie = vRP.isInDie({})
    custom.isMuted = vRP.isRTalked({})

    --deprecated
    local r, g, b = 0, 0x99, 255

    if custom.isDie == true then
      TriggerEvent("chatMessage", "알림", {255, 0, 255}, "죽은 상태에서는 메세지를 보낼 수 없습니다.")
    elseif custom.isComa == true and not (data.command == "ooc") then
      TriggerEvent("chatMessage", "알림", {255, 0, 255}, "혼수 상태에서는 메세지를 보낼 수 없습니다.")
    elseif custom.isMuted == true then
      TriggerEvent("chatMessage", "알림", {255, 0, 255}, "주등이락 상태에서는 메세지를 보낼 수 없습니다.")
    else
      if data.message:sub(1, 1) == "/" then
        if custom.isJailed == true then
          TriggerEvent("chatMessage", "알림", {255, 0, 255}, "구금 상태에서는 해당 메세지를 보낼 수 없습니다.")
        else
          ExecuteCommand(data.message:sub(2))
        end
      elseif data.command ~= nil then
        -- Execute Command
        -- Channel Commands will received at here
        if custom.isJailed == true then
          TriggerEvent("chatMessage", "알림", {255, 0, 255}, "구금 상태에서는 해당 메세지를 보낼 수 없습니다.")
        else
          ExecuteCommand(data.command .. ' ' .. data.message);
        end
      else
        TriggerServerEvent('_chat:messageEntered', GetPlayerName(id), { r, g, b }, data.message, custom)
      end
    end
  end

  cb('ok')
end)

-- Loaded Callback
RegisterNUICallback(
  "loaded",
  function(data, cb)
    TriggerServerEvent("chat:init")

    refreshCommands()
    --refreshThemes()

    chatLoaded = true

    cb("ok")
  end
)

-- Client Resource Start Event
AddEventHandler('onClientResourceStart', function(resName)
  -- Refresh Commands at every resource load
  Wait(500)
  refreshCommands()
end)

function refreshCommands()
  if GetRegisteredCommands then
    local registeredCommands = GetRegisteredCommands()

    local suggestions = {}

    for _, command in ipairs(registeredCommands) do
        if IsAceAllowed(('command.%s'):format(command.name)) then
            table.insert(suggestions, {
                name = '/' .. command.name,
                help = ''
            })
        end
    end

    TriggerEvent('chat:addSuggestions', suggestions)
  end
end

Citizen.CreateThread(
  function()
    SetTextChatEnabled(false)
    SetNuiFocus(false)

    while true do
      Wait(0)

      if not chatInputActive then
        if isShowUI then
          if IsControlPressed(0, 245) then
            shiftPressed = true
          else
            shiftPressed = false
          end

          if IsControlPressed(0, 21) then
            chatPressed = true
          else 
            chatPressed = false
          end
        end

        if isShowUI and shiftPressed and chatPressed then
          chatHeightChanging = true
        end
        
        if isShowUI and IsControlPressed(0, 245) and not chatHeightChanging --[[ INPUT_MP_TEXT_CHAT_ALL ]] then
          chatInputActive = true
          chatInputActivating = true

          SendNUIMessage(
            {
              type = "ON_OPEN"
            }
          )
        end
      end

      if chatHeightChanging and not IsControlPressed(0, 245) and not IsControlPressed(0, 21) then
        SendNUIMessage(
          {
            type = "ON_HEIGHT_CHANGE"
          }
        )

        chatHeightChanging = false
      else
        if chatInputActivating then
          if isShowUI and not IsControlPressed(0, 245) then
            SetNuiFocus(true, true)

            chatInputActivating = false
          end
        end

        if chatLoaded then
          local shouldBeHidden = false

          if IsScreenFadedOut() or IsPauseMenuActive() then
            shouldBeHidden = true
          end

          if (shouldBeHidden and not chatHidden) or (not shouldBeHidden and chatHidden) then
            chatHidden = shouldBeHidden

            SendNUIMessage(
              {
                type = "ON_SCREEN_STATE_CHANGE",
                shouldHide = shouldBeHidden
              }
            )
          end
        end
      end
    end
  end
)


