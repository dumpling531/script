description 'Reboot notice stuff by HDD'

ui_page 'html/index.html'

dependency "vrp"

client_scripts {
  'cl_reboot.lua',
}

server_scripts {
  '@vrp/lib/utils.lua',
  'sv_reboot.lua'
}

files {
  'html/index.html',
  'html/index.css',
  'html/script.js'
}