local Tunnel = module("vrp", "lib/Tunnel")
local Proxy = module("vrp", "lib/Proxy")

local vRP = Proxy.getInterface("vRP")
local vRPclient = Tunnel.getInterface("vRP","vRP_chatroles")

RegisterServerEvent('playerConnecting')

local reboot = false
local rebootTime = 0

RegisterCommand('rnotice', function (source, args, rawCommand)
  local user_id = vRP.getUserId({source})

  if vRP.hasPermission({user_id, "admin.rebootnotice"}) == true then
    reboot = true
    rebootTime = args[1]
    TriggerClientEvent('rebootNotice', -1, args[1]);
    TriggerClientEvent('chat:addMessage', -1, {
      color = {255, 255, 255},
      template = '<link href="https://fonts.googleapis.com/css2?family=Noto+Sans+KR:wght@300;400;500&display=swap" rel="stylesheet"><link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet"><style>* {font-family: "Noto Sans KR", sans-serif;}</style><div style="border-radius: 5px; width: 100%; height: auto; background-color: rgba(255,0,0, 0.55); color: white;"><div id="notice-content" style="display:flex; padding: 20px; flex-direction: column;"><div id="notice-content-title" style="display: flex; flex-direction: row; justify-content: left; width: 100%;"><div style="display: flex; flex-direction: column; justify-content: center;"><i class="fa fa-refresh fa-2x"></i></div><div style="display: flex; flex-direction: column; justify-content: center;"><h4 style="margin-left: 10px;">서버 리부팅 안내!</h4></div></div><div style="margin-top: 10px;"><p>더 나은 서버 환경을 제공하기 위해 서버 리부팅을 {0}분 후에 실시합니다.</p><p>유저 여러분들의 양해를 부탁드립니다!</p><p style="float: right; font-size: 8pt;">{1}</p></div></div></div>',
      args = {args[1], GetPlayerName(source)}
    });
  end
end, false)

AddEventHandler('playerConnecting', function (name, setKickReason, deferrals)
  local user_id = vRP.getUserId({source})
  deferrals.defer()
  deferrals.update("서버 리부팅이 예정되어 있는지 확인하는 중입니다 ...")
  Wait(2000)
  if reboot == true then
    deferrals.done("[HDD-RebootCheck] 서버 리부팅이 약 " .. rebootTime .. "분뒤 예정되어 있습니다! 리부팅이 완료 된 후 접속해주세요!")
  else
    Wait(0)
    deferrals.done()
  end
end)