const serverName = "지니";

const timer = document.getElementsByClassName('timer')[0];
const app = document.getElementsByClassName('app')[0];

app.classList.add('hidden');

window.addEventListener('message', (event) => {
  // NUI Event
  if (event.data.type === 'rebootNotify') {
    if (event.data.minute > 0) {
      app.classList.remove('hidden');
      app.classList.add('animated');
      app.classList.add('fadeIn');

      document.getElementsByClassName('title')[0].innerHTML = `${serverName}서버가 곧 리부팅 됩니다!`;

      let secounds = Number(event.data.minute) * 60;

      const interVal = setInterval(() => {
        secounds -= 1;
        const minutes = Math.floor(secounds / 60);
        const secoundsNow = secounds - (minutes * 60);

        timer.innerHTML = `${minutes.toString().padStart(2, "0")}:${secoundsNow.toString().padStart(2, "0")}`;

        if (secounds <= 30) {
          timer.classList.add('color-red');
        } else {
          timer.classList.remove('color-red');
        }

        if (secounds == 0 || secounds < 0) {
          clearInterval(interVal);
          timer.innerHTML = `00:00`;
        }
      }, 1000);
    }
  }
});